package Life;

import java.awt.*;

/**
* Description: Component Class for the 'Blank' marker
*
* Cell jbutton obj
*/
public class lifeCell extends javax.swing.JButton {
    // Default fields, assigns to default color values

    /**
     * preferred size, defaults etc
     */
    public lifeCell(java.awt.Color backgroundColor) {
        setPreferredSize(new java.awt.Dimension(25, 25));
        setContentAreaFilled(false);
        setBorderPainted(false);
        setBackground(backgroundColor);
        setOpaque(true);

    }


    /**
     * Method for setting background color of component
     *
     * @param backgroundColor Input color parameter
     */
    public void setBackgroundColor(java.awt.Color backgroundColor) {
        setBackground(backgroundColor);
        repaint();
    }
}
