package Life;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.util.*;

/**
 * Description: GUI Class for the lifeBoard
 *
 */
public class lifeGUI {
    // Declaring the Window
    private javax.swing.JFrame win;

    // Declaring the Content Pane
    private java.awt.Container c;
    private ArrayList<lifeCell> cellList = new ArrayList<lifeCell>();
    private JPanel[][] panelHolder;
    // Declaring each of the TTT Marker components, numbers correspond to matrix layout


    // Background color for the layout, will form the board's gridlines
    private static final Color live = Color.black;
    private static final Color dead = Color.white;
    private JButton[][] buttonArray;
    /**
     * Constructor for layout objects
     */
    public lifeGUI()
    {
        // Main Window
        win = new javax.swing.JFrame("TicTacToe");
        // Content Panel
        c = win.getContentPane();

        // Assigning default window parameters
        win.setLocation(50, 50);
        win.setSize(1000, 1000);
        win.setDefaultCloseOperation(javax.swing.JFrame.DISPOSE_ON_CLOSE);
        win.setVisible(true);
        win.toFront();
    }

    /**
     * Square cell grid layout
     */
    public void drawGridLayout(int[][] grid)
    {
        int x = grid.length;
        int y = grid[0].length;
        JButton[][] buttonArray = new JButton[grid.length][grid.length];
        //lifeCell[][] cell = new lifeCell[grid.length][grid[0].length];
        //layout
        c.setLayout(new java.awt.GridLayout(grid.length, grid[0].length, 1, 1));

        for (int i = 0; i < x; i++) {
            for (int j = 0; j < y; j++) {
                buttonArray[i][j] = new JButton();
                buttonArray[i][j].setPreferredSize(new java.awt.Dimension(25, 25));
                buttonArray[i][j].setContentAreaFilled(false);
                buttonArray[i][j].setBorderPainted(false);
                buttonArray[i][j].setBackground(dead);
                buttonArray[i][j].setOpaque(true);
                c.add(buttonArray[i][j], i, j);
            }
        }

        updateGridLayout(grid);

        //gridlines
        c.setBackground(Color.black);

        // This layout is very valid <3
        c.validate();

    }

    public void updateGridLayout(int[][] grid) {

        int x = grid.length;
        int y = grid[0].length;
        int index = 0;
        for (int i = 0; i < x; i++) {
            for (int j = 0; j < y; j++) {
                Component cell = c.getComponentAt(i,j);
                c.remove(cell);
                cell.setBackground(Color.cyan);
                if (grid[x - i - 1][j] == 1) {
                    //maybe arrays would work better?
                    //buttonArray[i][j].setBackground(dead);
                    c.getComponentAt(i,j).setBackground(dead);
                } else {
                   c.getComponentAt(i,j).setBackground(live);
                }
                index += 1;
            }
        }
        c.validate();
    }


}


